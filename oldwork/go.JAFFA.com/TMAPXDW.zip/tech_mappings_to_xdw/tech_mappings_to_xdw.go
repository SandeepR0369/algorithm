package main

import (
	"bytes"
	_ "encoding/csv"
	"flag"
	"fmt"
	_ "github.com/alexbrainman/odbc"
	"github.com/jmoiron/sqlx"
	slackrabbot "go.scope.charter.com/rabbot/slack"
	_ "io/ioutil"
	"os"
	"os/exec"
	"go.scope.charter.com/rio/log"
	"strings"
	"time"
)

var (
	date           string
	rows           *sqlx.Rows
	dbxIMP, dbxRIO *sqlx.DB
	PRIMARY_CSV_FILE    = `/tmp/xdw_nop_techmappingprimary_%s.txt`
	SECONDARY_CSV_FILE  = `/tmp/xdw_nop_techmappingsecondary_%s.txt`
	PRIMARY_TABLE      = `tbTechMappingsPrimary`
	SECONDARY_TABLE     = `tbTechMappingsSecondary`
	err            error
	sftp, prod, devTables, email     bool
	Log    = riolog.New("tech_mappings_to_xdw")
	email_body, email_subject string
	any_error, any_fatal bool
	SLACK_CHANNEL       = "dcc-alerts"
	SLACK_COUNT         = 0
	MAindex        = map[string]int{"West Central Florida": 1, "West Florida": 2, "East Central Florida": 3, "East Florida": 4, "TN/LA/AL": 5, "Michigan": 6, "Sierra Nevada": 7, "So Cal Central": 8, "So Cal South": 9, "Wisconsin": 10, "North Texas": 11, "Mountain States": 12, "Greenville SC/Georgia": 13, "Eastern North Carolina": 15, "Central States": 16, "Southern New England": 17, "Minnesota": 18, "Kansas City/Lincoln": 19, "Pacific Northwest": 20, "Central Texas": 21, "Hawaii": 22, "South Manhattan": 23, "N Manhattan/Staten Island": 24, "Brooklyn/Queens": 25, "Eastern New York": 26, "South Texas": 27, "So Cal North": 28, "Northern Ohio": 29, "Midwest Central": 30, "Midwest South": 31, "Kentucky": 32, "Western New York": 33, "Central New York": 34, "Northern New England": 35, "Western North Carolina": 36, "South Carolina": 37}
)

const (
  THIS                = `tech_mappings_to_xdw`
	INS_LIMIT           = 10000
	SLACK_LIMIT         = 10
	PRIMARY_DONE_FILE   = `/tmp/xdw_nop_techmappingprimary_%s.done`
	SECONDARY_DONE_FILE = `/tmp/xdw_nop_techmappingsecondary_%s.done`
	NOTIFY_DL           = `DL - XDW2-IT-Operations <XDW2-IT-Operations@charter.com>`
	CC = `c-joseph.buonomo@charter.com`
	GPG_USER            = `XDW ETL Server Grid <DL-CorpIT-ITSD-XDWP270@charter.com>`
	FTP_USER_DEV        = `xdw_nop@files.chartercom.com`
	FTP_PASSWORD_DEV    = `NRQ7Ghd9`
	FTP_USER_PROD       = `xdw_nop_prd@files.chartercom.com`
	FTP_PASSWORD_PROD   = `1tPiGK9E`
	TAGME               = "@buonomo"
	N2P_QUERY           = `
	SELECT 
	   n.id, 
	   REGEXP_REPLACE(cdf.prin, '^0+', '') AS prin 
  FROM 
	   charterentity.node n 
  JOIN 
	   charterentity.account acct ON acct.enabled=1 AND n.id=acct.node_id 
  JOIN
	   charterentity.cdf ON cdf.enabled=1 AND acct.cdf_id=cdf.id AND cdf.sys IS NOT NULL 
  WHERE
	   CAST(n.enabled AS STRING)='1'  
  GROUP BY
	   n.id, cdf.prin
  ORDER BY
	   COUNT(*) ASC
`
	PRIMARY_QUERY = `
select 
  IFNULL(REGEXP_REPLACE(e.mgtareaids,',','|'),'') AS ma_list,
	IFNULL(REGEXP_REPLACE(n.sys,'^0+',''),'') AS sys,
  IFNULL(e.employeeid,'N/A') AS employeeid,
  IFNULL(e.lastname,'N/A') AS lastname,
  IFNULL(e.firstname,'N/A') AS firstname,
  IFNULL(e.title,'N/A') AS title,
  '0' AS oneway,
  IFNULL(n.hub_name,'N/A') AS hub,
  IFNULL(n.rawname_name,'N/A') as node_name,
  IFNULL(n.id,'N/A') AS node_id,
  IFNULL(e.id,'N/A') AS emp_id
FROM 
  charterentity.employee e 
JOIN 
  charterentity.node n ON n.enabled=1 AND n.primarytech=e.id
JOIN
  charterentity.enterprise ent ON n.enterprise_id=ent.id
`
	SECONDARY_QUERY = `
select 
  IFNULL(REGEXP_REPLACE(e.mgtareaids,',','|'),'') AS ma_list,
	IFNULL(REGEXP_REPLACE(n.sys,'^0+',''),'') AS sys,
  IFNULL(e.employeeid,'N/A') AS employeeid,
  IFNULL(e.lastname,'N/A') AS lastname,
  IFNULL(e.firstname,'N/A') AS firstname,
  IFNULL(e.title,'N/A') AS title,
  '0' AS oneway,
  IFNULL(n.hub_name,'N/A') AS hub,
  IFNULL(n.rawname_name,'N/A') as node_name,
  IFNULL(n.id,'N/A') AS node_id,
  IFNULL(e.id,'N/A') AS emp_id
FROM 
  charterentity.employee e 
JOIN 
  charterentity.team t ON t.manager_id=e.id
JOIN 
  charterentity.node n ON n.enabled=1 AND n.team_id=t.id
JOIN
  charterentity.enterprise ent ON n.enterprise_id=ent.id
`
)
 
func main() {
	flag.BoolVar(&sftp, "sftp", false, "enable SFTP transfers")
	flag.BoolVar(&prod, "prod", false, "enable production transfers")
	flag.BoolVar(&email, "email", false, "enable email if prod")
	flag.BoolVar(&devTables, "devTables", false, "use dev tables for tech mappings")
	flag.Parse()
	any_error = false
	any_fatal = false
	info_(fmt.Sprintf("tech_mappings_to_xdw starting, sftp:%t, prod:%t, devTables:%t, email:%t", sftp, prod, devTables, email))

	if devTables {
		PRIMARY_TABLE      = "tbTechMappingsPrimary_dev"
		SECONDARY_TABLE    = "tbTechMappingsSecondary_dev"
	}

	openDBs()
	date = time.Now().UTC().Format("20060102")

	//fill_node2tech()   // This was a temporary workaround for missing tables/columns
	//fill_emp2mas()     // This was a temporary workaround for missing tables/columns

	if _, err = dbxRIO.Exec("DELETE FROM dbJob." + PRIMARY_TABLE); err != nil {
		error_(fmt.Sprintf("Error truncating dbJob." + PRIMARY_TABLE + ": %+v", err))
	}

	if _, err = dbxRIO.Exec("DELETE FROM dbJob." + SECONDARY_TABLE); err != nil {
		error_(fmt.Sprintf("Error truncating dbJob." + SECONDARY_TABLE + ": %+v", err))
	}

	//  build MAname - map id->name for mgtarea
	var MAname map[string]string
	MAname = make(map[string]string)
	if rows, err = dbxIMP.Queryx("SELECT id,name FROM charterentity.mgtarea WHERE CAST(enabled AS STRING)='1'"); err != nil {
		fatal_(fmt.Sprintf("Failed to get snr for N2P_QUERY: %+v", err))
	}
	for rows.Next() {
		var ma_id, ma_name string
		err := rows.Scan(&ma_id, &ma_name)
		if err != nil {
			error_(fmt.Sprintf("Failed to scan row for mgtareas: %+v", err))
			continue
		}
		MAname[ma_id] = ma_name
	}
	rows.Close()
	info_(fmt.Sprintf("%d name lookups loaded for mgtareas", len(MAname)))

	// read dbJob.tbSchedule
	var employeeStartTime map[string]string
	var employeeEndTime map[string]string
	employeeStartTime = make(map[string]string)
	employeeEndTime = make(map[string]string)
	if rows, err = dbxRIO.Queryx("SELECT IFNULL(employeeId,'N/A'),IFNULL(FROM_UNIXTIME(startDateTime),'NULL'),IFNULL(FROM_UNIXTIME(endDateTime),'NULL') FROM dbJob.tbSchedule"); err != nil {
		fatal_(fmt.Sprintf("Failed to get snr for tbSchedule: %+v", err))
	}
	for rows.Next() {
		var employee_id, startTime, endTime string
		err := rows.Scan(&employee_id, &startTime, &endTime)
		if err != nil {
			error_(fmt.Sprintf("Failed to scan row for tbSchedule: %+v", err))
			continue
		}
		if startTime != "NULL" {
			startTime = strings.Replace(startTime, "T", " ", -1)
			//startTime = startTime[0 : len(startTime)-6]
			employeeStartTime[employee_id] = startTime
		}
		if  endTime != "NULL" {
			endTime = strings.Replace(endTime, "T", " ", -1)
			//endTime = endTime[0 : len(endTime)-6]
			employeeEndTime[employee_id] = endTime
		}
	}
	rows.Close()
	info_(fmt.Sprintf("%d employees loaded from tbSchedule", len(employeeStartTime)))

	//  build node2prin  map id->prin for node
	var node2prin map[string]string
	node2prin = make(map[string]string)
	if rows, err = dbxIMP.Queryx(N2P_QUERY); err != nil {
		fatal_(fmt.Sprintf("Failed to get snr for N2P_QUERY: %+v", err))
	}
	for rows.Next() {
		var node_id, prin string
		err := rows.Scan(&node_id, &prin)
		if err != nil {
			error_(fmt.Sprintf("Failed to scan row for N2P_QUERY: %+v", err))
			continue
		}
		node2prin[node_id] = prin
	}
	rows.Close()
	info_(fmt.Sprintf("%d node to prin lookups loaded for nodes", len(node2prin)))

	primary_done_file := fmt.Sprintf(PRIMARY_DONE_FILE, date)
	done, err := os.Create(primary_done_file)
	if err != nil {
		fatal_(fmt.Sprintf("Failed to create primary DONE file %s: %+v", primary_done_file, err))
	}
	_, err = done.WriteString("FileName|FileLength|RowCount\n")
	if err != nil {
		error_(fmt.Sprintf("ERROR writing header row to primary DONE file:%+v", err))
	}

	//  Query primaries
	// Create the primary CSV file
	primary_rows := 0
	primary_bytes := 0
	primary_csv_file := fmt.Sprintf(PRIMARY_CSV_FILE, date)
	//defer os.Remove(primary_csv_file)
	f1, err := os.Create(primary_csv_file)
	if err != nil {
		fatal_(fmt.Sprintf("Failed to create primary CSV file %s: %+v", primary_csv_file, err))
	}

	// Write header row to CSV file
	n1, err := f1.WriteString("ID|PrimaryManagementAreaID|Sys|Prin|FiberNode|EmployeeNumber|TechLastName|TechFirstName|TechTitle|ValidFromDate|ValidToDate|OneWay|Excluded|Hub|NodeID\n")
	primary_rows += 1
	primary_bytes += n1
	INS1Q0 := "INSERT INTO dbJob." + PRIMARY_TABLE + " (PrimaryManagementAreaID,Sys,Prin,FiberNode,EmployeeNumber,TechLastName,TechFirstName,TechTitle,ValidFromDate,validToDate,OneWay,Excluded,Hub,NodeID) VALUES"
	ins1q := INS1Q0
	ins1count := 0
	info_(fmt.Sprintf("PRIMARY_QUERY:%s", strings.Replace(PRIMARY_QUERY, "\n", " ", -1)))
	if rows, err = dbxIMP.Queryx(PRIMARY_QUERY); err != nil {
		fatal_(fmt.Sprintf("Failed to get snr for PRIMARY_QUERY: %+v", err))
	}
	rowCount := 0
	for rows.Next() {
		var ma_list, sys, employeeid, lastname, firstname, title, oneway, hub, node_name, node_id, emp_id string
		excluded := "0"
		err := rows.Scan(&ma_list, &sys, &employeeid, &lastname, &firstname, &title, &oneway, &hub, &node_name, &node_id, &emp_id)
		if err != nil {
			error_(fmt.Sprintf("Failed to scan row for PRIMARY_QUERY: %+v", err))
			continue
		}
		for _, ma := range strings.Split(ma_list, "|") {
			rowCount += 1
			ma_name, exists := MAname[ma]
			if !exists {
				ma_name = "N/A"
			}
			var validfromdate, validtodate string
			if validfromdate, exists = employeeStartTime[emp_id]; !exists {
				validfromdate = "2018-07-10 00:00:00"
			}
			if validtodate, exists = employeeEndTime[emp_id]; !exists || validtodate < validfromdate {
				validtodate = "9999-12-31 23:59:59"
			}
			hub = strings.Replace(hub, "'", "''", -1)
			prin, exists := node2prin[node_id]
			if !exists {
				prin = ""
			}
			if len(sys) == 0 || len(prin) == 0 || len(node_name) == 0 || len(employeeid) == 0 || len(validtodate) == 0 {
				continue
			}
			if ins1count > 0 {
				ins1q += ","
			}
			n1, err = f1.WriteString(fmt.Sprintf("%d|%d|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s\n", rowCount, MAindex[ma_name], sys, prin, node_name, employeeid, lastname, firstname, title, validfromdate, validtodate, oneway, excluded, hub, node_id))
			primary_rows += 1
			primary_bytes += n1
			lastname = strings.Replace(lastname, "'", "''", -1)
			firstname = strings.Replace(firstname, "'", "''", -1)
			node_name = strings.Replace(node_name, "'", "", -1)
			ins1q += fmt.Sprintf("('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')", ma_name, sys, prin, node_name, employeeid, lastname, firstname, title, validfromdate, validtodate, oneway, excluded, hub, node_id)
			ins1count += 1
			if ins1count >= INS_LIMIT {
				info_(fmt.Sprintf("Writing %d rows to dbJob." + PRIMARY_TABLE, ins1count))
				if _, err = dbxRIO.Queryx(ins1q); err != nil {
					if strings.Index(err.Error(), "Stmt did not create a result set") == -1 {
						fatal_(fmt.Sprintf("Failed to insert to RIO: %+v, %s", err, ins1q))
					}
				}
				ins1count = 0
				ins1q = INS1Q0
			}
		}
	}
	if ins1count > 0 {
		info_(fmt.Sprintf("Writing final %d rows to dbJob." + PRIMARY_TABLE, ins1count))
		if _, err = dbxRIO.Queryx(ins1q); err != nil {
			if strings.Index(err.Error(), "Stmt did not create a result set") == -1 {
				error_(fmt.Sprintf("Failed to insert to RIO: %+v, %s", err, ins1q))
			}
		}
	}
	rows.Close()
	f1.Close()
	_, err = done.WriteString(fmt.Sprintf("%s|%d|%d\n", primary_csv_file[5:], primary_bytes, primary_rows))
	if err != nil {
		error_(fmt.Sprintf("ERROR writine DONE row for secondary:%+v", err))
	}
	info_("Primary list complete")
	done.Close()

	secondary_done_file := fmt.Sprintf(SECONDARY_DONE_FILE, date)
	done, err = os.Create(secondary_done_file)
	if err != nil {
		fatal_(fmt.Sprintf("Failed to create secondary DONE file %s: %+v", secondary_done_file, err))
	}
	_, err = done.WriteString("FileName|FileLength|RowCount\n")
	if err != nil {
		error_(fmt.Sprintf("ERROR writing header row to secondary DONE file:%+v", err))
	}

	//  Query secondaries

	// Create the CSV file
	secondary_csv_file := fmt.Sprintf(SECONDARY_CSV_FILE, date)
	secondary_rows := 0
	secondary_bytes := 0
	//defer os.Remove(secondary_csv_file)
	f2, err := os.Create(secondary_csv_file)
	if err != nil {
		fatal_(fmt.Sprintf("Failed to create secondary CSV file %s: %+v", secondary_csv_file, err))
	}

	// Write header row to CSV file
	n2, err := f2.WriteString("ID|SecondaryManagementAreaID|Sys|Prin|FiberNode|EmployeeNumber|TechLastName|TechFirstName|TechTitle|ValidFromDate|ValidToDate|OneWay|Hub|NodeID\n")
	secondary_rows += 1
	secondary_bytes += n2
	INS2Q0 := "INSERT INTO dbJob." + SECONDARY_TABLE + " (SecondaryManagementAreaID,Sys,Prin,FiberNode,EmployeeNumber,TechLastName,TechFirstName,TechTitle,ValidFromDate,ValidToDate,OneWay,Hub,NodeID) VALUES"
	ins2q := INS2Q0
	ins2count := 0
	info_(fmt.Sprintf("SECONDARY_QUERY:%s", strings.Replace(SECONDARY_QUERY, "\n", " ", -1)))
	if rows, err = dbxIMP.Queryx(SECONDARY_QUERY); err != nil {
		fatal_(fmt.Sprintf("Failed to get snr for SECONDARY_QUERY: %+v", err))
	}
	rowCount = 0
	for rows.Next() {
		var ma_list, sys, employeeid, lastname, firstname, title, oneway, hub, node_name, node_id, emp_id string
		err := rows.Scan(&ma_list, &sys, &employeeid, &lastname, &firstname, &title, &oneway, &hub, &node_name, &node_id, &emp_id)
		if err != nil {
			error_(fmt.Sprintf("Failed to scan row for SECONDARY_QUERY: %+v", err))
			continue
		}
		for _, ma := range strings.Split(ma_list, "|") {
			rowCount += 1
			ma_name, exists := MAname[ma]
			if !exists {
				ma_name = "N/A"
			}
			var validfromdate, validtodate string
			if validfromdate, exists = employeeStartTime[emp_id]; !exists {
				validfromdate = "2018-07-10 00:00:00"
			}
			if validtodate, exists = employeeEndTime[emp_id]; !exists || validtodate < validfromdate {
				validtodate = "9999-12-31 23:59:59"
			}
			hub = strings.Replace(hub, "'", "''", -1)
			prin, exists := node2prin[node_id]
			if !exists {
				prin = ""
			}
			if len(sys) == 0 || len(prin) == 0 || len(node_name) == 0 || len(employeeid) == 0 || len(validtodate) == 0 {
				continue
			}
			if ins2count > 0 {
				ins2q += ","
			}
			n2, err = f2.WriteString(fmt.Sprintf("%d|%d|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s\n", rowCount, MAindex[ma_name], sys, prin, node_name, employeeid, lastname, firstname, title, validfromdate, validtodate, oneway, hub, node_id))
			secondary_rows += 1
			secondary_bytes += n2
			lastname = strings.Replace(lastname, "'", "''", -1)
			firstname = strings.Replace(firstname, "'", "''", -1)
			node_name = strings.Replace(node_name, "'", "", -1)
			ins2q += fmt.Sprintf("('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')", ma_name, sys, prin, node_name, employeeid, lastname, firstname, title, validfromdate, validtodate, oneway, hub, node_id)
			ins2count += 1
			if ins2count >= INS_LIMIT {
				info_(fmt.Sprintf("Writing %d rows to dbJob." + SECONDARY_TABLE, ins2count))
				if _, err = dbxRIO.Queryx(ins2q); err != nil {
					if strings.Index(err.Error(), "Stmt did not create a result set") == -1 {
						fatal_(fmt.Sprintf("Failed to insert to RIO: %+v, %s", err, ins2q))
					}
				}
				ins2count = 0
				ins2q = INS2Q0
			}
		}
	}
	if ins2count > 0 {
		info_(fmt.Sprintf("Writing final %d rows to dbJob." + SECONDARY_TABLE, ins2count))
		if _, err = dbxRIO.Queryx(ins2q); err != nil {
			if strings.Index(err.Error(), "Stmt did not create a result set") == -1 {
				error_(fmt.Sprintf("Failed to insert to RIO: %+v, %s", err, ins2q))
			}
		}
	}
	rows.Close()
	f2.Close()
	_, err = done.WriteString(fmt.Sprintf("%s|%d|%d\n", secondary_csv_file[5:], secondary_bytes, secondary_rows))
	if err != nil {
		error_(fmt.Sprintf("ERROR writing DONE row for secondary:%+v", err))
	}
	done.Close()
	info_("Secondary list complete")

	encrypt_file(fmt.Sprintf(PRIMARY_CSV_FILE, date))
	encrypt_file(fmt.Sprintf(SECONDARY_CSV_FILE, date))
	if sftp {
		sftp_file(fmt.Sprintf(PRIMARY_CSV_FILE, date)+".gpg", FTP_USER_DEV, FTP_PASSWORD_DEV)
		sftp_file(fmt.Sprintf(PRIMARY_DONE_FILE, date), FTP_USER_DEV, FTP_PASSWORD_DEV)
		sftp_file(fmt.Sprintf(SECONDARY_CSV_FILE, date)+".gpg", FTP_USER_DEV, FTP_PASSWORD_DEV)
	        sftp_file(fmt.Sprintf(SECONDARY_DONE_FILE, date), FTP_USER_DEV, FTP_PASSWORD_DEV)
		if prod {
			sftp_file(fmt.Sprintf(PRIMARY_CSV_FILE, date)+".gpg", FTP_USER_PROD, FTP_PASSWORD_PROD)
			sftp_file(fmt.Sprintf(PRIMARY_DONE_FILE, date), FTP_USER_PROD, FTP_PASSWORD_PROD)
			sftp_file(fmt.Sprintf(SECONDARY_CSV_FILE, date)+".gpg", FTP_USER_PROD, FTP_PASSWORD_PROD)
			sftp_file(fmt.Sprintf(SECONDARY_DONE_FILE, date), FTP_USER_PROD, FTP_PASSWORD_PROD)
		}
	}

	if any_error {
		msg_("completed with errors")
		email_subject = "tech_mappings_to_xdw completed with errors"
	} else {
		msg_("completed successfully")
		email_subject = "tech_mappings_to_xdw completed successfully"
	}
	if prod && email {
		email_(NOTIFY_DL, CC, email_subject, email_body)
	} else {
		email_(CC, CC, email_subject, email_body)
	}
}

func email_(DL, CC, subject, body string) {
	// Create and fill the body file
	defer os.Remove("/tmp/tech_mappings_to_xdw.body")
	b, err := os.Create("/tmp/tech_mappings_to_xdw.body")
	if err != nil {
		Log.Errorf("Failed to create body file: %+v", err)
	}
	if _, errp := b.WriteString(body + "\n"); errp != nil {
		Log.Errorf("Failed to write body file: %+v", errp)
	}
	err = b.Close()

	var out bytes.Buffer
	var stderr bytes.Buffer
	cmd := exec.Command("mailx", "-q", "/tmp/tech_mappings_to_xdw.body", "-c", CC, "-s", subject, DL)
	cmd.Stdout = &out
	cmd.Stderr = &stderr
	err1 := cmd.Run()
	if err1 != nil {
		fmt.Println(fmt.Sprint(err1) + ": " + stderr.String())
		return
	}
	if len(out.String()) > 0 {
		info_(fmt.Sprintf("Result from exec: " + out.String()))
	} else {
		info_(fmt.Sprintf("/tmp/tech_mappings_to_xdw.body has been successfully sent to %s", DL))
	}
}

func encrypt_file(filename string) {
	// gpg --trust-model always --batch --yes -e -r "XDW ETL Server Grid <DL-CorpIT-ITSD-XDWP270@charter.com>" /tmp/primary_tech_map.csv
	var out, stderr bytes.Buffer
	cmd := exec.Command("gpg", "--trust-model", "always", "--batch", "--yes", "-e", "-r", GPG_USER, filename)
	cmd.Stdout = &out
	cmd.Stderr = &stderr
	if err := cmd.Run(); err != nil {
		error_(fmt.Sprintf("exec of gpg file %s"+fmt.Sprint(err)+": "+stderr.String(), filename))
	}
	info_(fmt.Sprintf("Output FROM gpg of %s: "+out.String(), filename))
}

func sftp_file(filename string, FTP_USER string, FTP_PASSWORD string) {
	// Create and fill the password file
	pass_file := fmt.Sprintf("/tmp/xdw_sftp.%d.pass", os.Getpid())
	defer os.Remove(pass_file)
	p, err := os.Create(pass_file)
	if err != nil {
		error_(fmt.Sprintf("Failed to create the password file: %+v", err))
	}
	if _, errb := p.WriteString(FTP_PASSWORD); errb != nil {
		error_(fmt.Sprintf("Failed to write password file: %+v", errb))
	}
	if err = p.Close(); err != nil {
		error_(fmt.Sprintf("Failed to close the password file: %+v", err))
	}

	// Create and fill the batch file
	batch_file := fmt.Sprintf("/tmp/xdw_sftp.%d.batch", os.Getpid())
	defer os.Remove(batch_file)
	b, err := os.Create(batch_file)
	if err != nil {
		error_(fmt.Sprintf("Failed to create the batch file: %+v", err))
	}
	if _, errp := b.WriteString(fmt.Sprintf("put %s\nbye\n", filename)); errp != nil {
		error_(fmt.Sprintf("Failed to write the batch file: %+v", errp))
	}
	if err = b.Close(); err != nil {
		error_(fmt.Sprintf("Failed to close the batch file: %+v", err))
	}

	// Copy CSV file to files.chartercom.com
	var out2 bytes.Buffer
	var stderr2 bytes.Buffer
	cmd2 := exec.Command("sshpass", "-f", pass_file, "sftp", "-oBatchMode=no", "-b", batch_file, FTP_USER)
	cmd2.Stdout = &out2
	cmd2.Stderr = &stderr2
	if err := cmd2.Run(); err != nil {
		error_(fmt.Sprintf(fmt.Sprint(err) + ": " + stderr2.String()))
	} else {
		email_body += fmt.Sprintf("File %s has been transferred to %s\n", filename, FTP_USER)
                info_(fmt.Sprintf("File %s has been transferred to %s\n", filename, FTP_USER))
	}
	info_(fmt.Sprintf("Output FROM sshpass: " + out2.String()))
	os.Remove(pass_file)
}

func openDBs() {

	// Connect to Impala database
	dbxIMP, err = sqlx.Connect("odbc", "DSN=IMPALA")
	if err != nil {
		for retryCount := 6; retryCount >= 0; retryCount-- {
			if retryCount == 0 {
				fatal_("Too many retries trying to create Impala connection")
			}
			info_(fmt.Sprintf("Failed to create impala connection, retrying: %+v\n", err))
			dbxIMP, err = sqlx.Connect("odbc", "DSN=IMPALA")
			if err == nil {
				info_(fmt.Sprintf("retry succeeded for impala connection"))
				break
			}
		}
	}
	info_("Impala connection success")

	// Connect to RIO orders database
	dbxRIO, err = sqlx.Connect("odbc", "DSN=RIO")
	if err != nil {
		for retryCount := 6; retryCount >= 0; retryCount-- {
			if retryCount == 0 {
				fatal_("Too many retries trying to create RIO connection")
			}
			info_(fmt.Sprintf("Failed to create RIO connection, retrying: %+v\n", err))
			dbxRIO, err = sqlx.Connect("odbc", "DSN=RIO")
			if err == nil {
				info_("retry succeeded for RIO connection")
				break
			}
		}
	}
	info_("RIO connection success")
}

func error_(msg string) {
  if SLACK_COUNT < SLACK_LIMIT {
	  SLACK_COUNT += 1
	  err := slackrabbot.PostMessage(slackrabbot.Message{Channel: SLACK_CHANNEL, Message: fmt.Sprintf("*ERROR*| %s %s", msg, TAGME)})
	  if err != nil {
	  	error_(fmt.Sprintf("Post to %s failed:%+v", SLACK_CHANNEL, err))
	  }
	}
	Log.Errorf(msg)
	any_error = true
	email_body += "ERROR:" + msg + "\n"
}

func info_(msg string) {
	Log.Infof(msg)
}

func msg_(msg string) {
  if SLACK_COUNT < SLACK_LIMIT {
	  SLACK_COUNT += 1
	  err := slackrabbot.PostMessage(slackrabbot.Message{Channel: SLACK_CHANNEL, Message: fmt.Sprintf("%s *MESSAGE*| %s %s", THIS, msg, TAGME)})
	  if err != nil {
	  	Log.Errorf("Post to %s failed:%+v", SLACK_CHANNEL, err)
		}
	}
	Log.Infof(msg)
}

func fatal_(msg string) {
	err := slackrabbot.PostMessage(slackrabbot.Message{Channel: SLACK_CHANNEL, Message: fmt.Sprintf("%s *FATAL*| %s %s", THIS, msg, TAGME)})
	if err != nil {
		Log.Errorf("Post to %s failed:%+v", SLACK_CHANNEL, err)
	}
	email_body += "FATAL:" + msg + "\n"
	if prod {
               email_(NOTIFY_DL, CC, "tech_mappings_to_xdw failed", email_body)
        } else {
               email_(CC, CC, "tech_mappings_to_xdw failed", email_body)
        }
	Log.Fatalf(msg)
}

func check(e error) {
	if e != nil {
		panic(e)
	}
}
